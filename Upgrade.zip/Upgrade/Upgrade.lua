local ADDON_PATH = "Interface\\AddOns\\Upgrade\\"
local SMALL_UPGRADE_SOUND = ADDON_PATH .. "smallupgrade.ogg"
local BIG_UPGRADE_SOUND = ADDON_PATH .. "bigupgrade.ogg"
local MEDIA_PATH = ADDON_PATH .. "Media\\"
local STONE_TEXTURE_PRIMARY = MEDIA_PATH .. "StoneBackground.png"
local STONE_TEXTURE_FALLBACK = MEDIA_PATH .. "StoneBackground.png"
local MOSS_TEXTURE_PRIMARY = MEDIA_PATH .. "StoneBottom.png"
local MOSS_TEXTURE_FALLBACK = MEDIA_PATH .. "StoneBottom.png"
local PREVIEW_MOSS_RATIO = 0.36
local PREVIEW_UNIFORM_TINT_R = 0.58
local PREVIEW_UNIFORM_TINT_G = 0.58
local PREVIEW_UNIFORM_TINT_B = 0.58
local PREVIEW_UNIFORM_TINT_A = 1
local PREVIEW_SPLIT_DIVIDER_X_OFFSET = 10
local PREVIEW_SPLIT_DIVIDER_Y_OFFSET = -250
local PREVIEW_SPLIT_DIVIDER_LEFT_INSET = 0
local PREVIEW_SPLIT_DIVIDER_RIGHT_INSET = -100
local PREVIEW_SPLIT_DIVIDER_HEIGHT = 0
local SOUND_COOLDOWN_SECONDS = 10
local lastSoundTime = -SOUND_COOLDOWN_SECONDS
local SOUND_SETTINGS_ADDON_NAME = "Upgrade"
local SOUND_SETTINGS_DEFAULTS = {
    enabled = true,
    small = true,
    big = true,
}
local soundSettings = {
    enabled = true,
    small = true,
    big = true,
}

local function EnsureSoundSettings()
    if type(UpgradeSoundConfig) ~= "table" then
        UpgradeSoundConfig = {}
    end
    if type(UpgradeSoundConfig.enabled) ~= "boolean" then
        UpgradeSoundConfig.enabled = SOUND_SETTINGS_DEFAULTS.enabled
    end
    if type(UpgradeSoundConfig.small) ~= "boolean" then
        UpgradeSoundConfig.small = SOUND_SETTINGS_DEFAULTS.small
    end
    if type(UpgradeSoundConfig.big) ~= "boolean" then
        UpgradeSoundConfig.big = SOUND_SETTINGS_DEFAULTS.big
    end

    soundSettings.enabled = UpgradeSoundConfig.enabled
    soundSettings.small = UpgradeSoundConfig.small
    soundSettings.big = UpgradeSoundConfig.big
    return UpgradeSoundConfig
end

local function SetSoundSetting(key, value)
    local cfg = EnsureSoundSettings()
    cfg[key] = value and true or false
    soundSettings[key] = cfg[key]
end

local function TrySetTexture(textureObject, primaryPath, fallbackPath)
    if not textureObject then return false end
    if primaryPath and primaryPath ~= "" then
        textureObject:SetTexture(primaryPath)
        if textureObject.GetTexture and textureObject:GetTexture() then
            return true
        end
    end
    if fallbackPath and fallbackPath ~= "" then
        textureObject:SetTexture(fallbackPath)
        if textureObject.GetTexture and textureObject:GetTexture() then
            return true
        end
    end
    return false
end

local function ApplyStoneWindowBackground(windowFrame, leftInset, rightInset, topInset, bottomInset)
    local stoneTex = windowFrame:CreateTexture(nil, "BACKGROUND")
    stoneTex:SetPoint("TOPLEFT", windowFrame, "TOPLEFT", leftInset, -topInset)
    stoneTex:SetPoint("BOTTOMRIGHT", windowFrame, "BOTTOMRIGHT", -rightInset, bottomInset)
    stoneTex:SetTexCoord(0, 1, 0, 1)
    stoneTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    if not TrySetTexture(stoneTex, STONE_TEXTURE_PRIMARY, STONE_TEXTURE_FALLBACK) then
        stoneTex:SetTexture(STONE_TEXTURE_FALLBACK)
        stoneTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    end
end

local function ApplySplitWindowBackground(windowFrame, leftInset, rightInset, topInset, bottomInset, lowerRatio)
    local topPrimary = STONE_TEXTURE_PRIMARY
    local topFallback = STONE_TEXTURE_FALLBACK
    local bottomPrimary = MOSS_TEXTURE_PRIMARY
    local bottomFallback = MOSS_TEXTURE_FALLBACK

    local topTex = windowFrame:CreateTexture(nil, "BACKGROUND")
    topTex:SetPoint("TOPLEFT", windowFrame, "TOPLEFT", leftInset, -topInset)
    topTex:SetPoint("BOTTOMRIGHT", windowFrame, "BOTTOMRIGHT", -rightInset, bottomInset)
    topTex:SetTexCoord(0, 1, 0, 1)
    topTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    if not TrySetTexture(topTex, topPrimary, topFallback) then
        topTex:SetTexture(topFallback)
        topTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    end

    local bottomTex = windowFrame:CreateTexture(nil, "BORDER")
    bottomTex:SetPoint("BOTTOMLEFT", windowFrame, "BOTTOMLEFT", leftInset, bottomInset)
    bottomTex:SetPoint("BOTTOMRIGHT", windowFrame, "BOTTOMRIGHT", -rightInset, bottomInset)
    bottomTex:SetTexCoord(0, 1, 0, 1)
    bottomTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    if not TrySetTexture(bottomTex, bottomPrimary, bottomFallback) then
        bottomTex:SetTexture(bottomFallback)
        bottomTex:SetVertexColor(PREVIEW_UNIFORM_TINT_R, PREVIEW_UNIFORM_TINT_G, PREVIEW_UNIFORM_TINT_B, PREVIEW_UNIFORM_TINT_A)
    end

    local splitDivider = windowFrame:CreateTexture(nil, "OVERLAY")
    splitDivider:SetDrawLayer("OVERLAY")
    splitDivider:SetVertexColor(1, 1, 1, 1)
    if not TrySetTexture(splitDivider, "Interface\\DialogFrame\\UI-DialogBox-Divider") then
        splitDivider:SetTexture("Interface\\Tooltips\\UI-TooltipDivider-Transparent")
    end

    local function UpdateBottomHeight()
        local interiorHeight = (windowFrame:GetHeight() or 0) - topInset - bottomInset
        if interiorHeight < 1 then
            interiorHeight = 1
        end
        local ratio = lowerRatio or 0.50
        local h = math.floor(interiorHeight * ratio + 0.5)
        if h < 1 then h = 1 end
        bottomTex:SetHeight(h)

        local seamY = bottomInset + h
        splitDivider:ClearAllPoints()
        splitDivider:SetPoint("LEFT", windowFrame, "LEFT", PREVIEW_SPLIT_DIVIDER_LEFT_INSET + PREVIEW_SPLIT_DIVIDER_X_OFFSET, seamY + PREVIEW_SPLIT_DIVIDER_Y_OFFSET)
        splitDivider:SetPoint("RIGHT", windowFrame, "RIGHT", -PREVIEW_SPLIT_DIVIDER_RIGHT_INSET + PREVIEW_SPLIT_DIVIDER_X_OFFSET, seamY + PREVIEW_SPLIT_DIVIDER_Y_OFFSET)
        splitDivider:SetHeight(PREVIEW_SPLIT_DIVIDER_HEIGHT)
    end

    windowFrame:HookScript("OnSizeChanged", UpdateBottomHeight)
    UpdateBottomHeight()
end

local function EscapePattern(text)
    return text:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
end

local function BuildChatPattern(globalString)
    local pattern = EscapePattern(globalString)
    pattern = pattern:gsub("%%%%s", "(.+)")
    pattern = pattern:gsub("%%%%d", "(%%d+)")
    return "^" .. pattern .. "$"
end

local SELF_LOOT_PATTERNS = {
    BuildChatPattern(LOOT_ITEM_SELF or "You receive loot: %s."),
    BuildChatPattern(LOOT_ITEM_SELF_MULTIPLE or "You receive loot: %sx%d."),
    BuildChatPattern(LOOT_ITEM_PUSHED_SELF or "You receive item: %s."),
    BuildChatPattern(LOOT_ITEM_PUSHED_SELF_MULTIPLE or "You receive item: %sx%d."),
}

local function IsSelfLootMessage(message)
    if not message or message == "" then
        return false
    end

    for _, pattern in ipairs(SELF_LOOT_PATTERNS) do
        if message:match(pattern) then
            return true
        end
    end

    return false
end

local function TryPlaySound(soundPath)
    if not soundSettings.enabled then
        return
    end
    local now = GetTime()
    if (now - lastSoundTime) < SOUND_COOLDOWN_SECONDS then
        return
    end

    PlaySoundFile(soundPath)
    lastSoundTime = now
end

local function HandleLootMessage(message)
    if not IsSelfLootMessage(message) then
        return
    end

    local hasSmallUpgrade = false
    local hasBigUpgrade = false

    for link in message:gmatch("|Hitem:.-|h%[.-%]|h") do
        local itemName = link:match("|h%[(.-)%]|h")
        if itemName then
            local plusValue = tonumber(itemName:match("%+(%d+)"))
            if plusValue and plusValue >= 1 and plusValue <= 25 then
                if plusValue >= 15 then
                    hasBigUpgrade = true
                else
                    hasSmallUpgrade = true
                end
            end
        end
    end

    if hasBigUpgrade and soundSettings.big then
        TryPlaySound(BIG_UPGRADE_SOUND)
    elseif hasSmallUpgrade and soundSettings.small then
        TryPlaySound(SMALL_UPGRADE_SOUND)
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("CHAT_MSG_LOOT")
frame:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        local addonName = ...
        if addonName == SOUND_SETTINGS_ADDON_NAME then
            EnsureSoundSettings()
        end
        return
    end

    local message = ...
    if event == "CHAT_MSG_LOOT" then
        HandleLootMessage(message)
    end
end)

-- AIO Upgrade UI
local GOLD  = "|cffffd100"
local GREEN = "|cff00ff00"
local RED   = "|cffff3333"
local WHT   = "|cffffffff"
local BLUE  = "|cff00c0ff"
local ORNG  = "|cffff8000"
local GREY  = "|cff888888"
local R     = "|r"

local function FmtGold(c)
    local COIN_GOLD = "|cffffd100"
    local COIN_SILVER = "|cffc7c7cf"
    local COIN_COPPER = "|cffeda55f"

    local function CoinPart(color, amount, unit)
        return color .. tostring(amount) .. unit .. R
    end

    if not c then return "0g" end
    c = math.floor(c)
    local g = math.floor(c / 10000)
    local s = math.floor((c % 10000) / 100)
    local co = c % 100
    if s == 0 and co == 0 then
        return CoinPart(COIN_GOLD, g, "g")
    end
    if co == 0 then
        return CoinPart(COIN_GOLD, g, "g") .. " " .. CoinPart(COIN_SILVER, s, "s")
    end
    return CoinPart(COIN_GOLD, g, "g") .. " " .. CoinPart(COIN_SILVER, s, "s") .. " " .. CoinPart(COIN_COPPER, co, "c")
end

local function Pct(v)
    return string.format("%.1f", tonumber(v) or 0)
end

local function ColorizeItemName(name, entry, itemLink)
    local itemName = name or "Unknown"
    local quality = nil

    if itemLink and itemLink ~= "" then
        local _, _, q = GetItemInfo(itemLink)
        quality = q
    end
    if (not quality) and entry then
        local _, _, q = GetItemInfo(entry)
        quality = q
    end

    if quality ~= nil then
        local r, g, b = GetItemQualityColor(quality)
        if r and g and b then
            return string.format("|cff%02x%02x%02x%s|r",
                math.floor(r * 255 + 0.5),
                math.floor(g * 255 + 0.5),
                math.floor(b * 255 + 0.5),
                itemName)
        end
    end

    local linkColor = itemLink and itemLink:match("|c(%x%x%x%x%x%x%x%x)|Hitem") or nil
    if linkColor then
        return "|c" .. linkColor .. itemName .. "|r"
    end

    return WHT .. itemName .. R
end

local UpgradeUI = {}
local curData   = nil
local cMode     = 0
local expectPreviewShow = false
local purchasePending = false
local purchaseDeadline = 0
local stoneBuyRequestId = 0
local upgradePending = false
local upgradeDeadline = 0
local upgradeRequestId = 0
local SOUND_GEAR_IDLE_R, SOUND_GEAR_IDLE_G, SOUND_GEAR_IDLE_B = 0.82, 0.82, 0.82
local SOUND_GEAR_HOVER_R, SOUND_GEAR_HOVER_G, SOUND_GEAR_HOVER_B = 1.00, 0.82, 0.00

local soundOptionsDrop = CreateFrame("Frame", "UpgUISoundOptionsDrop", UIParent, "UIDropDownMenuTemplate")
UIDropDownMenu_Initialize(soundOptionsDrop, function(self, level)
    if level ~= 1 then return end

    EnsureSoundSettings()

    local title = UIDropDownMenu_CreateInfo()
    title.isTitle = true
    title.notCheckable = true
    title.text = "Addon Sounds"
    UIDropDownMenu_AddButton(title, level)

    local allInfo = UIDropDownMenu_CreateInfo()
    allInfo.text = "Enable all upgrade sounds"
    allInfo.isNotRadio = true
    allInfo.keepShownOnClick = true
    allInfo.checked = soundSettings.enabled
    allInfo.func = function()
        SetSoundSetting("enabled", not soundSettings.enabled)
    end
    UIDropDownMenu_AddButton(allInfo, level)

    local smallInfo = UIDropDownMenu_CreateInfo()
    smallInfo.text = "Small upgrade sound"
    smallInfo.isNotRadio = true
    smallInfo.keepShownOnClick = true
    smallInfo.checked = soundSettings.small
    smallInfo.disabled = not soundSettings.enabled
    smallInfo.func = function()
        SetSoundSetting("small", not soundSettings.small)
    end
    UIDropDownMenu_AddButton(smallInfo, level)

    local bigInfo = UIDropDownMenu_CreateInfo()
    bigInfo.text = "Big upgrade sound"
    bigInfo.isNotRadio = true
    bigInfo.keepShownOnClick = true
    bigInfo.checked = soundSettings.big
    bigInfo.disabled = not soundSettings.enabled
    bigInfo.func = function()
        SetSoundSetting("big", not soundSettings.big)
    end
    UIDropDownMenu_AddButton(bigInfo, level)
end, "MENU")

local function CreateSoundGearButton(parentFrame, x, y)
    local gearBtn = CreateFrame("Button", nil, parentFrame)
    gearBtn:SetWidth(20)
    gearBtn:SetHeight(20)
    gearBtn:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", x, y)
    gearBtn:EnableMouse(true)
    gearBtn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")

    local gearTex = gearBtn:CreateTexture(nil, "ARTWORK")
    gearTex:SetTexture("Interface\\Icons\\Trade_Engineering")
    gearTex:SetWidth(16)
    gearTex:SetHeight(16)
    gearTex:SetPoint("CENTER", 0, 0)
    gearTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    gearTex:SetVertexColor(SOUND_GEAR_IDLE_R, SOUND_GEAR_IDLE_G, SOUND_GEAR_IDLE_B, 1)

    gearBtn:SetScript("OnEnter", function(self)
        gearTex:SetVertexColor(SOUND_GEAR_HOVER_R, SOUND_GEAR_HOVER_G, SOUND_GEAR_HOVER_B, 1)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOMLEFT")
        GameTooltip:SetText("Sound Options")
        GameTooltip:Show()
    end)
    gearBtn:SetScript("OnLeave", function()
        gearTex:SetVertexColor(SOUND_GEAR_IDLE_R, SOUND_GEAR_IDLE_G, SOUND_GEAR_IDLE_B, 1)
        GameTooltip:Hide()
    end)
    gearBtn:SetScript("OnClick", function(self)
        EnsureSoundSettings()
        ToggleDropDownMenu(1, nil, soundOptionsDrop, self, 0, 0)
    end)

    return gearBtn
end

-- List frame
local LF = CreateFrame("Frame", "UpgUIList", UIParent)
LF:SetSize(360, 460)
LF:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
LF:SetFrameStrata("HIGH")
LF:SetFrameLevel(100)
LF:EnableMouse(true)
LF:SetMovable(false)
LF:SetBackdrop({
    bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
})
ApplyStoneWindowBackground(LF, 11, 12, 12, 10)
LF:Hide()
tinsert(UISpecialFrames, "UpgUIList")
LF:SetScript("OnHide", function()
    CloseDropDownMenus()
end)

local lhBg = LF:CreateTexture(nil, "ARTWORK")
lhBg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
lhBg:SetWidth(340); lhBg:SetHeight(64)
lhBg:SetPoint("TOP", 0, 12)

local lhTx = LF:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
lhTx:SetPoint("TOP", LF, "TOP", 0, -5)
lhTx:SetWidth(200)
lhTx:SetJustifyH("CENTER")
lhTx:SetText("Select Item to Upgrade")

local lhCl = CreateFrame("Button", nil, LF, "UIPanelCloseButton")
lhCl:SetPoint("TOPRIGHT", LF, "TOPRIGHT", -1, -1)
lhCl:SetScript("OnClick", function() LF:Hide() end)
local lfGearBtn = CreateSoundGearButton(LF, 8, -8)

local lScr = CreateFrame("ScrollFrame", "UpgUIListScr", LF, "UIPanelScrollFrameTemplate")
lScr:SetPoint("TOPLEFT",     LF, "TOPLEFT",     12,  -44)
local LIST_SCROLL_BOTTOM_INSET = 2
lScr:SetPoint("BOTTOMRIGHT", LF, "BOTTOMRIGHT", -30, LIST_SCROLL_BOTTOM_INSET)
local lCon = CreateFrame("Frame", nil, lScr)
lCon:SetSize(296, 10)
lScr:SetScrollChild(lCon)
local LIST_SCROLLBAR_BOTTOM_GAP = 5
local lScrollBar = _G[lScr:GetName() .. "ScrollBar"]
local lScrollDown = _G[lScr:GetName() .. "ScrollBarScrollDownButton"]
if lScrollBar and lScrollDown then
    lScrollDown:ClearAllPoints()
    lScrollDown:SetPoint("TOP", lScrollBar, "BOTTOM", 0, LIST_SCROLLBAR_BOTTOM_GAP)
end

local LBTNS = {}
local LIST_ROW_HEIGHT = 44
local LIST_ROW_STEP = 46
local LIST_BOTTOM_PADDING = 6
for i = 1, 19 do
    local b = CreateFrame("Button", nil, lCon)
    b:SetSize(296, LIST_ROW_HEIGHT)
    b:SetPoint("TOPLEFT", lCon, "TOPLEFT", 0, -(i - 1) * LIST_ROW_STEP)

    local hl = b:CreateTexture(nil, "HIGHLIGHT")
    hl:SetTexture("Interface\\QuestFrame\\UI-QuestLogTitleHighlight")
    hl:SetBlendMode("ADD"); hl:SetAllPoints()

    local ico = b:CreateTexture(nil, "ARTWORK")
    ico:SetSize(38, 38); ico:SetPoint("LEFT", b, "LEFT", 4, 0); b.ico = ico

    local nm = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    nm:SetPoint("TOPLEFT", ico, "TOPRIGHT", 8, -2)
    nm:SetWidth(240); nm:SetJustifyH("LEFT"); b.nm = nm

    local sub = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sub:SetPoint("BOTTOMLEFT", ico, "BOTTOMRIGHT", 8, 2)
    sub:SetWidth(240); sub:SetJustifyH("LEFT"); b.sub = sub

    if i > 1 then
        local sep = b:CreateTexture(nil, "BACKGROUND")
        sep:SetTexture("Interface\\Common\\UI-TooltipDivider-Transparent")
        sep:SetHeight(1)
        sep:SetPoint("TOPLEFT",  b, "TOPLEFT",  0, 0)
        sep:SetPoint("TOPRIGHT", b, "TOPRIGHT", 0, 0)
    end

    b:SetScript("OnClick", function(self)
        if self.slot ~= nil then
            LF:Hide()
            expectPreviewShow = true
            AIO.Handle("UpgradeUI", "GetItemPreview", self.slot)
        end
    end)
    b:Hide()
    LBTNS[i] = b
end

function UpgradeUI:ShowList(items)
    for i = 1, #LBTNS do LBTNS[i]:Hide(); LBTNS[i].slot = nil end

    if not items or #items == 0 then
        local b = LBTNS[1]
        b.ico:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        b.nm:SetText(WHT .. "No eligible equipped items." .. R)
        b.sub:SetText(GREY .. "Equip Rare+ armor/weapons with stats." .. R)
        b:Show()
        lCon:SetHeight(LIST_ROW_STEP + LIST_BOTTOM_PADDING); lScr:SetVerticalScroll(0); LF:Show()
        return
    end

    table.sort(items, function(a, b) return a.slot < b.slot end)
    local n = math.min(#items, #LBTNS)
    for i = 1, n do
        local item = items[i]; local b = LBTNS[i]
        b.slot = item.supported and item.slot or nil
        b.ico:SetTexture(GetItemIcon(item.entry) or "Interface\\Icons\\INV_Misc_QuestionMark")
        b.nm:SetText(GOLD .. item.name .. R)
        if item.supported then
            b.sub:SetText(GREEN .. Pct(item.chance) .. "% success" .. R .. "  " .. GOLD .. FmtGold(item.cost) .. R)
        else
            b.sub:SetText(RED .. (item.reason or "Not supported") .. R)
        end
        b:Show()
    end
    lCon:SetHeight(n * LIST_ROW_STEP + LIST_BOTTOM_PADDING); lScr:SetVerticalScroll(0); LF:Show()
end

-- Preview frame
local PF = CreateFrame("Frame", "UpgUIPreview", UIParent)
PF:SetSize(400, 480)
PF:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
PF:SetFrameStrata("HIGH")
PF:SetFrameLevel(100)
PF:EnableMouse(true)
PF:SetMovable(false)
PF:SetBackdrop({
    bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
})
ApplySplitWindowBackground(PF, 11, 12, 12, 11, PREVIEW_MOSS_RATIO)
PF:Hide()
tinsert(UISpecialFrames, "UpgUIPreview")
PF:SetScript("OnHide", function()
    CloseDropDownMenus()
    expectPreviewShow = false
    purchasePending = false
    upgradePending = false
end)

local phBg = PF:CreateTexture(nil, "ARTWORK")
phBg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header")
phBg:SetWidth(220); phBg:SetHeight(64)
phBg:SetPoint("TOP", 0, 12)

local phTx = PF:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
phTx:SetPoint("TOP", PF, "TOP", 0, -5)
phTx:SetText("Upgrade Item")

local phCl = CreateFrame("Button", nil, PF, "UIPanelCloseButton")
phCl:SetPoint("TOPRIGHT", PF, "TOPRIGHT", -1, -1)
phCl:SetScript("OnClick", function() PF:Hide() end)
local pfGearBtn = CreateSoundGearButton(PF, 8, -8)

local backBtn = CreateFrame("Button", nil, PF, "UIPanelButtonTemplate")
backBtn:SetSize(70, 22)
backBtn:SetPoint("TOPLEFT", PF, "TOPLEFT", 14, -28)
backBtn:SetText("< Back")
backBtn:SetScript("OnClick", function()
    PF:Hide()
    AIO.Handle("UpgradeUI", "GetEquippedItems")
end)

local icoFr = CreateFrame("Frame", nil, PF)
icoFr:SetSize(60, 60)
icoFr:SetPoint("TOPLEFT", PF, "TOPLEFT", 16, -54)
icoFr:SetBackdrop({
    bgFile   = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = false, tileSize = 16, edgeSize = 16,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
})
icoFr:SetBackdropColor(0, 0, 0, 1)
icoFr:SetBackdropBorderColor(0.5, 0.5, 0.5, 1)

local icoTx = icoFr:CreateTexture(nil, "ARTWORK")
icoTx:SetPoint("TOPLEFT",     icoFr, "TOPLEFT",      3, -3)
icoTx:SetPoint("BOTTOMRIGHT", icoFr, "BOTTOMRIGHT",  -3,  3)
icoTx:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")

local itemNm = PF:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
itemNm:SetPoint("TOPLEFT",  icoFr, "TOPRIGHT",  10,  -2)
itemNm:SetPoint("TOPRIGHT", PF,    "TOPRIGHT",  -14, -54)
itemNm:SetJustifyH("LEFT")
itemNm:SetText("Select an item")

local slotLbl = PF:CreateFontString(nil, "OVERLAY", "GameFontNormal")
slotLbl:SetPoint("TOPLEFT", itemNm, "BOTTOMLEFT", 0, -2)
slotLbl:SetTextColor(0.6, 0.6, 0.6)
slotLbl:SetText("")

local div1 = PF:CreateTexture(nil, "ARTWORK")
div1:SetTexture("Interface\\Common\\UI-TooltipDivider-Transparent")
div1:SetHeight(4)
div1:SetPoint("TOPLEFT",  PF, "TOPLEFT",  14,  -128)
div1:SetPoint("TOPRIGHT", PF, "TOPRIGHT", -14, -128)

-- Stats panel (no scrollbar)
local stScr = CreateFrame("Frame", "UpgUIStatsPanel", PF)
stScr:SetPoint("TOPLEFT",     PF, "TOPLEFT",     14,  -136)
stScr:SetPoint("BOTTOMRIGHT", PF, "BOTTOMRIGHT", -14,  178)
local stCon = CreateFrame("Frame", nil, stScr)
stCon:SetAllPoints(stScr)

local stTx = stCon:CreateFontString(nil, "OVERLAY", "GameFontNormal")
stTx:SetPoint("TOPLEFT", stCon, "TOPLEFT", 4, -4)
stTx:SetPoint("TOPRIGHT", stCon, "TOPRIGHT", -4, -4)
stTx:SetJustifyH("LEFT")
stTx:SetSpacing(1)
stTx:SetText("")

local div2 = PF:CreateTexture(nil, "ARTWORK")
div2:SetTexture("Interface\\Common\\UI-TooltipDivider-Transparent")
div2:SetHeight(4)
div2:SetPoint("BOTTOMLEFT",  PF, "BOTTOMLEFT",  14,  172)
div2:SetPoint("BOTTOMRIGHT", PF, "BOTTOMRIGHT", -14,  172)

local stoneLbl = PF:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
stoneLbl:SetPoint("BOTTOMLEFT", PF, "BOTTOMLEFT", 14, 154)
stoneLbl:SetText("Protection Stone:")

local stoneCostLbl = PF:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
stoneCostLbl:SetPoint("LEFT", stoneLbl, "RIGHT", 10, 0)
stoneCostLbl:SetPoint("RIGHT", PF, "RIGHT", -14, 0)
stoneCostLbl:SetJustifyH("RIGHT")
stoneCostLbl:SetTextColor(1.0, 0.82, 0.0)
stoneCostLbl:SetText("Stone Cost: Keepsake -   Legendary -")

local stoneDrop = CreateFrame("Frame", "UpgUIStoneDropDown", PF, "UIDropDownMenuTemplate")
stoneDrop:SetPoint("BOTTOMLEFT", PF, "BOTTOMLEFT", 2, 114)
UIDropDownMenu_SetWidth(stoneDrop, 150)
UIDropDownMenu_SetButtonWidth(stoneDrop, 170)
UIDropDownMenu_JustifyText(stoneDrop, "LEFT")
UIDropDownMenu_SetText(stoneDrop, "None")

local buyBtn = CreateFrame("Button", nil, PF, "UIPanelButtonTemplate")
buyBtn:SetSize(68, 22)
buyBtn:SetPoint("LEFT", stoneDrop, "RIGHT", -6, 2)
buyBtn:SetText("Buy...")
buyBtn:SetEnabled(false)

local feedLbl = PF:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
feedLbl:SetPoint("BOTTOM", PF, "BOTTOM", 0, 90)
feedLbl:SetWidth(360)
feedLbl:SetText("")

local upBtn = CreateFrame("Button", nil, PF, "UIPanelButtonTemplate")
upBtn:SetSize(200, 40)
upBtn:SetPoint("BOTTOM", PF, "BOTTOM", 0, 38)
upBtn:SetText("Upgrade")
upBtn:SetEnabled(false)

local function IsStoneModeAvailable(mode, d)
    if mode == 0 then return true end
    if not d then return false end
    if mode == 1 then return (d.keepCount or 0) > 0 end
    if mode == 2 then return (d.legCount or 0) > 0 end
    return false
end

local function GetStoneModeLabel(mode, d)
    if mode == 1 then
        local count = d and (d.keepCount or 0) or 0
        local chance = d and (d.keepChance or 0) or 0
        return string.format("Keepsake (x%d) - %.1f%%", count, chance)
    elseif mode == 2 then
        local count = d and (d.legCount or 0) or 0
        return string.format("Legendary (x%d) - Guaranteed", count)
    end
    return "None"
end

local function GetStonePrice(mode, d)
    if mode == 1 then
        return tonumber(d and d.keepPrice or 0) or 0
    elseif mode == 2 then
        return tonumber(d and d.legPrice or 0) or 0
    end
    return 0
end

local KEEPSAKE_STONE_ITEM_ID = 900104
local LEGENDARY_STONE_ITEM_ID = 900103
local KEEPSAKE_ICON_FALLBACK = "Interface\\Icons\\INV_Misc_Gem_Pearl_03"
local LEGENDARY_ICON_FALLBACK = "Interface\\Icons\\INV_Misc_Gem_Ruby_01"

local function GetStoneMenuIcon(mode)
    local itemId, fallbackIcon
    if mode == 1 then
        itemId = KEEPSAKE_STONE_ITEM_ID
        fallbackIcon = KEEPSAKE_ICON_FALLBACK
    else
        itemId = LEGENDARY_STONE_ITEM_ID
        fallbackIcon = LEGENDARY_ICON_FALLBACK
    end

    local tex = GetItemIcon(itemId)
    if tex and tex ~= "" then
        return tex
    end
    return fallbackIcon
end

local function UpdateStoneCostLabel(d)
    local keep = GetStonePrice(1, d)
    local leg  = GetStonePrice(2, d)
    local keepTxt = (keep > 0) and FmtGold(keep) or "N/A"
    local legTxt  = (leg  > 0) and FmtGold(leg)  or "N/A"
    stoneCostLbl:SetText(string.format("Stone Cost: Keepsake %s   Legendary %s", keepTxt, legTxt))
end

local function SetMode(m)
    if not IsStoneModeAvailable(m, curData) then
        m = 0
    end
    cMode = m
    UIDropDownMenu_SetText(stoneDrop, GetStoneModeLabel(cMode, curData))
end

UIDropDownMenu_Initialize(stoneDrop, function(self, level)
    if level ~= 1 then return end

    local function addOption(mode)
        local info = UIDropDownMenu_CreateInfo()
        info.text = GetStoneModeLabel(mode, curData)
        info.checked = (cMode == mode)
        info.func = function()
            SetMode(mode)
            CloseDropDownMenus()
        end
        UIDropDownMenu_AddButton(info, level)
    end

    addOption(0)
    if IsStoneModeAvailable(1, curData) then
        addOption(1)
    end
    if IsStoneModeAvailable(2, curData) then
        addOption(2)
    end
end)

local stoneBuyDrop = CreateFrame("Frame", "UpgUIStoneBuyDrop", PF, "UIDropDownMenuTemplate")

UIDropDownMenu_Initialize(stoneBuyDrop, function(self, level)
    if level ~= 1 then return end

    local function addBuyOption(mode)
        local info = UIDropDownMenu_CreateInfo()
        local price = GetStonePrice(mode, curData)
        local label = (mode == 1) and "Keepsake Stone" or "Legendary Upgrade Stone"
        local icon = GetStoneMenuIcon(mode)
        if price > 0 then
            info.text = string.format("|T%s:14:14:0:0|t %s - %s", icon, label, FmtGold(price))
        else
            info.text = string.format("|T%s:14:14:0:0|t %s - %s", icon, label, "N/A")
        end
        info.func = function()
            if not curData or curData.slot == nil then return end
            if purchasePending then return end
            purchasePending = true
            purchaseDeadline = GetTime() + 4.0
            stoneBuyRequestId = stoneBuyRequestId + 1
            buyBtn:SetEnabled(false)
            feedLbl:SetText(GREY .. "Purchasing..." .. R)
            AIO.Handle("UpgradeUI", "BuyStone", mode, 1, curData.slot, stoneBuyRequestId)
            CloseDropDownMenus()
        end
        UIDropDownMenu_AddButton(info, level)
    end

    addBuyOption(1)
    addBuyOption(2)
end, "MENU")

local buyWatch = CreateFrame("Frame")
buyWatch:SetScript("OnUpdate", function()
    if not purchasePending then return end
    if GetTime() < purchaseDeadline then return end
    purchasePending = false
    if curData then
        buyBtn:SetEnabled(true)
    end
    feedLbl:SetText(RED .. "Purchase timed out. Try again." .. R)
    if curData and curData.slot ~= nil then
        AIO.Handle("UpgradeUI", "GetItemPreview", curData.slot)
    end
end)

buyBtn:SetScript("OnClick", function(self)
    if not curData then return end
    ToggleDropDownMenu(1, nil, stoneBuyDrop, self, 0, 0)
end)

upBtn:SetScript("OnClick", function()
    if not curData or curData.slot == nil then return end
    if upgradePending then return end
    upgradePending = true
    upgradeDeadline = GetTime() + 5.0
    upgradeRequestId = upgradeRequestId + 1
    upBtn:SetEnabled(false)
    feedLbl:SetText(GREY .. "Upgrading..." .. R)
    AIO.Handle("UpgradeUI", "DoUpgrade", curData.slot, cMode, upgradeRequestId)
end)

local upgradeWatch = CreateFrame("Frame")
upgradeWatch:SetScript("OnUpdate", function()
    if not upgradePending then return end
    if GetTime() < upgradeDeadline then return end
    upgradePending = false
    if curData then
        upBtn:SetEnabled(true)
    end
    feedLbl:SetText(RED .. "Upgrade timed out. Try again." .. R)
end)

local function ShowCurrentItemTooltip(owner)
    if not curData then return end
    local link = curData.itemLink
    if (not link or link == "") and curData.entry then
        link = "item:" .. tostring(curData.entry) .. ":0:0:0:0:0:0:0"
    end
    if not link or link == "" then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetHyperlink(link)
    GameTooltip:Show()
end

icoFr:EnableMouse(true)
icoFr:SetScript("OnEnter", function(self) ShowCurrentItemTooltip(self) end)
icoFr:SetScript("OnLeave", function() GameTooltip:Hide() end)

local itemHoverArea = CreateFrame("Frame", nil, PF)
itemHoverArea:SetFrameLevel(PF:GetFrameLevel() + 5)
itemHoverArea:EnableMouse(true)
itemHoverArea:SetPoint("TOPLEFT", itemNm, "TOPLEFT", 0, 0)
itemHoverArea:SetPoint("TOPRIGHT", PF, "TOPRIGHT", -14, -54)
itemHoverArea:SetHeight(44)
itemHoverArea:SetScript("OnEnter", function(self) ShowCurrentItemTooltip(self) end)
itemHoverArea:SetScript("OnLeave", function() GameTooltip:Hide() end)

function UpgradeUI:ShowPreview(d)
    if not d then return end
    local shouldShow = PF:IsShown() or expectPreviewShow
    expectPreviewShow = false
    purchasePending = false
    upgradePending = false
    local wantedMode = cMode
    curData = d; SetMode(wantedMode); feedLbl:SetText("")
    UpdateStoneCostLabel(d)
    local coloredName = ColorizeItemName(d.itemName, d.entry, d.itemLink)
    icoTx:SetTexture(d.entry and GetItemIcon(d.entry) or "Interface\\Icons\\INV_Misc_QuestionMark")
    itemNm:SetText(coloredName)
    slotLbl:SetText(GREY .. (d.slotLabel or "") .. R)

    local tier = tonumber(d.tier) or 0
    local targetTier = tonumber(d.targetTier) or tier
    local critLevels = tonumber(d.critLevels) or 0
    local critDenom = tonumber(d.critDenom) or 0
    local badLuck = tonumber(d.badLuck) or 0
    local baseChance = tonumber(d.baseChance) or 0
    local totalChance = tonumber(d.chance) or 0
    local failChance = tonumber(d.failChance) or (100 - totalChance)
    local pityBonus = totalChance - baseChance
    if pityBonus < 0 then pityBonus = 0 end

    local critLine
    if critLevels > 0 and critDenom > 0 then
        critLine = WHT .. "Critical:     " .. R .. ORNG .. "1/" .. critDenom .. " for +" .. critLevels .. " extra levels" .. R
    else
        critLine = WHT .. "Critical:     " .. R .. GREY .. "N/A" .. R
    end

    local L = {}
    local function A(s) L[#L + 1] = s end
    A(BLUE .. "-- Upgrade Preview --" .. R)
    A(WHT  .. "Slot:         " .. R .. (d.slotLabel or ""))
    A(WHT  .. "Item:         " .. R .. coloredName)
    A(WHT  .. "Tier:         " .. R .. GOLD .. "+" .. tier .. R .. GREY .. "  ->  " .. R .. GREEN .. "+" .. targetTier .. R)
    A(critLine)
    A(WHT .. "Base Success: " .. R .. GREEN .. Pct(baseChance) .. "%" .. R)
    A(WHT .. "Pity Bonus:   " .. R .. GREEN .. "+" .. Pct(pityBonus) .. "%" .. R .. GREY .. " (" .. badLuck .. " stacks)" .. R)
    A(WHT .. "Success:      " .. R .. GREEN .. Pct(totalChance) .. "%" .. R
        .. "   " .. WHT .. "Fail: " .. R .. RED .. Pct(failChance) .. "%" .. R)
    A(WHT .. "Cost:         " .. R .. GOLD .. FmtGold(d.cost) .. R)
    A(WHT .. "You have:     " .. R .. GOLD .. FmtGold(d.money) .. R)

    stTx:SetText(table.concat(L, "\n"))
    SetMode(wantedMode)
    buyBtn:SetEnabled(true)
    upBtn:SetEnabled(true)
    if shouldShow then
        PF:Show()
    end
end

function UpgradeUI:ApplyItemMeta(meta)
    if type(meta) ~= "table" then return end
    curData = curData or {}
    if meta.slot ~= nil then curData.slot = meta.slot end
    if meta.slotLabel ~= nil then curData.slotLabel = meta.slotLabel end
    if meta.entry ~= nil then curData.entry = meta.entry end
    if meta.itemLink ~= nil then curData.itemLink = meta.itemLink end
    if meta.itemName ~= nil then curData.itemName = meta.itemName end
    if meta.tier ~= nil then curData.tier = meta.tier end
    if meta.targetTier ~= nil then curData.targetTier = meta.targetTier end

    local coloredName = ColorizeItemName(curData.itemName, curData.entry, curData.itemLink)
    icoTx:SetTexture(curData.entry and GetItemIcon(curData.entry) or "Interface\\Icons\\INV_Misc_QuestionMark")
    itemNm:SetText(coloredName)
    slotLbl:SetText(GREY .. (curData.slotLabel or "") .. R)
end

function UpgradeUI:ShowError(msg)
    local shouldShow = PF:IsShown() or expectPreviewShow
    expectPreviewShow = false
    purchasePending = false
    upgradePending = false
    UpdateStoneCostLabel(nil)
    stTx:SetText(RED .. (msg or "An error occurred.") .. R)
    upBtn:SetEnabled(false)
    buyBtn:SetEnabled(false)
    if shouldShow then
        PF:Show()
    end
end

function UpgradeUI:OnResult(ok, msg, isCrit)
    upgradePending = false
    if ok then
        feedLbl:SetText(isCrit and ORNG .. (msg or "CRITICAL upgrade!") .. R or GREEN .. (msg or "Successfully upgraded!") .. R)
    else
        feedLbl:SetText(RED .. (msg or "Failed.") .. R)
        upBtn:SetEnabled(true)  -- re-enable now on fail; success waits for ShowPreview
    end
end

function UpgradeUI:OnStoneShopResult(ok, msg)
    purchasePending = false
    if curData then
        buyBtn:SetEnabled(true)
    end
    if ok then
        feedLbl:SetText(GREEN .. (msg or "Purchased.") .. R)
    else
        feedLbl:SetText(RED .. (msg or "Purchase failed.") .. R)
    end
end

-- AIO UpgradeUI handler: make registration idempotent to avoid stale-cache asserts.
do
    local UpgHandlers = {}

    UpgHandlers.OpenUI = function(_player)
        if GossipFrame and GossipFrame:IsShown() then CloseGossip() end
        AIO.Handle("UpgradeUI", "GetEquippedItems")
    end
    UpgHandlers.ReceiveEquippedItems = function(_player, items)           UpgradeUI:ShowList(items)            end
    UpgHandlers.ReceiveItemPreview   = function(_player, d)               UpgradeUI:ShowPreview(d)             end
    UpgHandlers.ReceiveItemMeta      = function(_player, d)               UpgradeUI:ApplyItemMeta(d)          end
    UpgHandlers.ReceiveError         = function(_player, msg)             UpgradeUI:ShowError(msg)             end
    UpgHandlers.UpgradeResult        = function(_player, ok, msg, isCrit) UpgradeUI:OnResult(ok, msg, isCrit) end
    UpgHandlers.StoneShopResult      = function(_player, ok, msg)         UpgradeUI:OnStoneShopResult(ok, msg) end
    UpgHandlers.GetItemPreview       = function(_player, slot)            AIO.Handle("UpgradeUI", "GetItemPreview", slot) end

    local _realAddHandlers   = AIO.AddHandlers
    local _realRegisterEvent = AIO.RegisterEvent
    local _upgRegistered     = false

    AIO.RegisterEvent = function(name, func)
        if name == "UpgradeUI" then return end
        return _realRegisterEvent(name, func)
    end

    AIO.AddHandlers = function(name, t)
        if name == "UpgradeUI" then
            if type(t) == "table" then
                for k, v in pairs(t) do
                    if type(v) == "function" then UpgHandlers[k] = v end
                end
            end
            if not _upgRegistered then
                _upgRegistered = true
                _realRegisterEvent("UpgradeUI", function(player, key, ...)
                    if key and UpgHandlers[key] then UpgHandlers[key](player, ...) end
                end)
            end
            return UpgHandlers
        end
        return _realAddHandlers(name, t)
    end

    AIO.AddHandlers("UpgradeUI", UpgHandlers)

    -- Replace stale cached addon code before AIO init.
    local _evict = CreateFrame("Frame")
    _evict:RegisterEvent("VARIABLES_LOADED")
    _evict:SetScript("OnEvent", function()
        if AIO_sv_Addons and AIO_sv_Addons["UpgradeUI"] then
            AIO_sv_Addons["UpgradeUI"].code = " -- stale entry replaced by Upgrade addon"
        end
        _evict:UnregisterAllEvents()
    end)
end

local function PrintUpgradeChatMessage(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff00c0ff[Upgrade]|r " .. tostring(msg or ""))
    end
end

local function OpenUpgradeMenuFromSlash()
    if not AIO or type(AIO.Handle) ~= "function" then
        PrintUpgradeChatMessage("AIO is not available. Upgrade UI cannot be opened.")
        return
    end

    if GossipFrame and GossipFrame:IsShown() then
        CloseGossip()
    end
    AIO.Handle("UpgradeUI", "GetEquippedItems")
end

SLASH_UPGRADE1 = "/upgrade"
SlashCmdList.UPGRADE = function()
    OpenUpgradeMenuFromSlash()
end
